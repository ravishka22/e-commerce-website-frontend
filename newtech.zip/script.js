function changeView(){
    var signUpBox = document.getElementById("signupbox");
    var signInBox = document.getElementById("signinbox");

    signUpBox.classList.toggle("d-none");
    signInBox.classList.toggle("d-none");
}